print("Starting ODMPY-NG")

cookies = []

if len(sys.argv) < 2:
    print("Error: Config file path is required")
    print("Usage: python interactive.py <config_file_path>")
    sys.exit(1)

config_file = sys.argv[1]
if len(sys.argv) < 2:
    print("Error: Config file path is required")
    print("Usage: python interactive.py <config_file_path>")
    sys.exit(1)

config_file = sys.argv[1]
with open(config_file) as f: # {"library": "", "user": "", "pass": "", "download-dir": ""}
    cover_dir = os.path.abspath(os.path.join(tmp_dir, "cover.jpg"))
    output_file = os.path.abspath(os.path.join(download_path, book_title.replace(" ", "")+".m4b"))
    filter_table = str.maketrans(dict.fromkeys(string.punctuation))
    download_path = os.path.abspath(os.path.join(scraper_config["download-dir"], 
                                          book_author.translate(filter_table), 
