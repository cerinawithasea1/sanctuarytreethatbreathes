def encodeAAC(tmp_dir, in_file, out_file):
    in_file = os.path.join(tmp_dir, in_file)
    out_file = os.path.join(tmp_dir, out_file)

    try:
        # Use argument list instead of string command
        result = subprocess.run([
            'ffmpeg', 
            '-y', 
            '-i', in_file, 
            '-c:a', 'aac', 
            '-b:a', '32k', 
            out_file
        ], check=False) # 32k or 64k
        
        return result.returncode == 0 or result.returncode == 1
    except Exception as e:
        print(f"Error encoding AAC: {e}")
        return False
def encodeMetadata(tmp_dir, in_file, out_file, chapter_file, cover_file):
    in_file = os.path.join(tmp_dir, in_file)
    chapter_file = os.path.join(tmp_dir, chapter_file)
    # Ensure cover_file is properly handled (it might be an absolute path already)
    if not os.path.isabs(cover_file):
        cover_file = os.path.join(tmp_dir, cover_file)

    try:
        # Use argument list instead of string command
        result = subprocess.run([
            'ffmpeg', 
            '-y', 
            '-i', in_file, 
            '-i', cover_file, 
            '-i', chapter_file, 
            '-map', '0', 
            '-map', '1', 
            '-map_metadata', '2', 
            '-map_chapters', '2', 
            '-c', 'copy', 
            '-disposition:1', 'attached_pic', 
            out_file
        ], check=False)
        
        return result.returncode == 0 or result.returncode == 1
    except Exception as e:
        print(f"Error encoding metadata: {e}")
        return False
